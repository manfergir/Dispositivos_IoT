# Práctica 4 – Contiki-NG: Monitorización de la Información

En la carpeta actual se encuentran los **códigos fuente, archivos de configuración de Docker y documentación** correspondientes a la **Práctica 4**, que abarca los **Ejercicios 1 y 2**.

---

## Estructura de la práctica

La práctica está organizada en dos subcarpetas independientes (`ej1/` y `ej2/`)

### Ejercicio 1 – Publicación MQTT Básica

Contiene la implementación inicial para la lectura del sensor de temperatura interno de la tarjeta **Nordic NRF52840**.
El firmware realiza la conversión y envío de la temperatura exclusivamente en **grados Fahrenheit** al broker MQTT, publicando el dato en el topic:
* `temp_F`

---

### Ejercicio 2 – Monitorización Completa con Grafana

Contiene la versión ampliada de la aplicación. En este ejercicio se publican múltiples métricas simultáneamente para su visualización en un dashboard de **Grafana**.
Las métricas enviadas son:
* **Temperatura en grados centígrados:** Topic `temp_c`
* **Temperatura en grados Fahrenheit:** Topic `temp_F`
* **Estado del pulsador (Botón 1):** Topic `switch`

---

## Organización de Archivos

Cada ejercicio (`ej1` y `ej2`) mantiene la misma estructura interna para facilitar el despliegue:

* **`docker/`**
    Contiene el archivo `docker-compose.yml` y las configuraciones necesarias para levantar la infraestructura de monitorización (Mosquitto, MQTT Exporter, Prometheus y Grafana).

* **`rpl-udp/`**
    Contiene código de referencia de prácticas anteriores (redes IPv6/RPL) utilizado como base para la conectividad.

---

## Compilación y Despliegue

### 1. Infraestructura (Docker)
Para levantar el sistema de monitorización, acceder a la carpeta `docker/` del ejercicio correspondiente y ejecutar:
```bash
docker-compose up -d