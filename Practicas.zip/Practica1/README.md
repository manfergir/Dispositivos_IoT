# Práctica 1 – Introducción a Contiki-NG y Procesos

En la carpeta actual se encuentran el **código fuente, Makefile y carpeta `build`** correspondientes a los **ejercicios 2, 4 (se salta el 3) y 5 de la Práctica 1**.

---

## Estructura de la práctica

### Ejercicio 2 – Creación de Procesos (Hola Mundo)

Contiene la implementación básica de un proceso en Contiki-NG.
El objetivo de este ejercicio es comprender la estructura de las macros `PROCESS_THREAD`, `PROCESS_BEGIN` y `PROCESS_END`.

---

### Ejercicio 4 – Temporizadores y LEDs

Contiene el código fuente para el manejo de **temporizadores de eventos (`etimer`)**.
En este ejercicio se implementa un bucle infinito controlado por tiempo que gestiona el parpadeo de los LEDs.

---

### Ejercicio 5 – Sensores y Eventos de Usuario

Contiene el desarrollo de una aplicación que interactúa con el hardware de la mota, específicamente con el **botón de usuario**.
Se demuestra cómo capturar eventos asíncronos externos (pulsación del botón) y utilizarlos para modificar el comportamiento del programa o el estado de los LEDs.

---

## Compilación y Ejecución

### COLOCAR LA CARPETA EN LA RUTA **contiki-ng/examples**

Cada ejercicio puede compilarse y ejecutarse directamente desde su propia carpeta.

Se ha configurado explícitamente el `Makefile` de cada ejercicio para que apunte correctamente a la ruta del sistema, permitiendo la ejecución de los comandos estándar sin necesidad de ajustes adicionales.

---

## Autores

Trabajo realizado por:

- **Manuel Fernández Giráldez**
- **Nuria Sorrentino Rebull**