# Práctica 2 – Temporizadores y Simulación en COOJA

En la carpeta actual se encuentran los **códigos fuente, archivos de configuración (`project-conf.h`), Makefiles y scripts** correspondientes a los **ejercicios 1, 2 y 3 de la Práctica 2: Simulación de Redes Inalámbricas con Contiki-NG**.

La práctica está organizada por ejercicios, siguiendo la estructura indicada a continuación.

---

## Estructura de la práctica

### Ejercicio 1 – Parpadeo de LEDs con Eventos

Contiene el código fuente (`main.c`) para la gestión de **procesos concurrentes y temporizadores** en Contiki-NG.

A diferencia de la práctica anterior, la aplicación consta de tres tareas sincronizadas mediante **eventos personalizados (`process_post` en modo BROADCAST)**:
* **Tarea 1:** Parpadeo del LED Verde cada 2 segundos tras recibir el evento de inicio.
* **Tarea 2:** Parpadeo del LED Amarillo cada 4 segundos tras recibir el evento de inicio.
* **Tarea 3:** Temporizador maestro que, tras 3 segundos, lanza el evento global de arranque para despertar a las otras dos tareas.

---

### Ejercicio 2 – Topología Lineal y Webserver (RPL)

Contiene la configuración para una simulación en COOJA diseñada para forzar el **enrutamiento multisalto**. La red está formada por:
* **1 Nodo Frontera (Border Router):** Mota tipo SKY.
* **3 Nodos Cliente:** Motas tipo Z1.

Los nodos se han dispuesto en una **topología lineal (cadena)** mediante el modelo de radio *UDGM: Distance Loss*, obligando a que el tráfico pase de un nodo a otro (1 → 2 → 3 → 4) para llegar al destino.

---

### Ejercicio 3 – Cliente/Servidor UDP y Sensores

Contiene los códigos fuente modificados para el **Cliente (`udp-client.c`)** y el **Servidor (`border-router.c`)**.

Se simula el envío de datos de temperatura (alternando entre interna y externa) desde los clientes Z1 hacia el servidor SKY.

---

## Compilación

### COLOCAR LA CARPETA EN LA RUTA **contiki-ng/examples**

Cada ejercicio puede compilarse de forma independiente desde su propia carpeta, ya que los **Makefiles están configurados correctamente con la ruta a `Makefile.include`**, permitiendo la ejecución directa de los comandos de compilación sin dependencias externas.

---

## Autores

Trabajo realizado por:

- **Manuel Fernández Giráldez**
- **Nuria Sorrentino Rebull**